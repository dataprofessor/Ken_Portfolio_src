---
title: "Data Science Portfolio"
featured_image: '/images/dennis-kummer-52gEprMkp7M-unsplash.jpg'
description: "Hi! My name is Ken Jee."
---
Welcome to my Data Science Portfolio. My passion is understanding the intersection of data science and sports analytics.
