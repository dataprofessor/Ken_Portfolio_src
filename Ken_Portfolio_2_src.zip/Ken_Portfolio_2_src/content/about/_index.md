---
title: "About"
description: "Hi! My name is Ken Jee. I'm a Data Scientist. My expertise is in Sports Analytics."
featured_image: '/images/jeremy-thomas-rMmibFe4czY-unsplash.jpg'
---
{{< figure src="/images/ken-jee.png"  >}}

Data Science and Sports Analytics are my passions. My name is Ken Jee and I have been working in the data science field doing sports analytics for the last 5 years. I have held data science positions in companies ranging from startups to fortune 100 organizations. I transitioned into data science from a business and consulting background. When I was first starting out on my data science journey I was extremely lost; there were very few resources for me to learn about this field from. I decided to start making youtube videos to share my experiences and to hopefully help others get break into the data science and sports analytics fields.
