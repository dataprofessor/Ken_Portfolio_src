---
title: Contact
featured_image: "images/notebook.jpg"
omit_header_text: true
description: We'd love to hear from you
type: page
menu: main

---

Follow me on these social media platforms.

Platform |	URL
---|---
YouTube:|	https://www.youtube.com/c/kenjee1?sub_confirmation=1
Website:|	https://www.playingnumbers.com, https://kennethjee.com/
Twitter:|	https://twitter.com/KenJee_DS
LinkedIn:|	https://www.linkedin.com/in/kenjee/
Medium:|	https://medium.com/@kenneth.b.jee
GitHub:|	https://github.com/PlayingNumbers
